<?php
/** front-page.php – siehe vorherige Version (unverändert) */
get_header(); ?>
<section class="hero">
  <div class="hero-bg" role="img" aria-label="<?php esc_attr_e('Natur & Bewegung','kneipzentrum'); ?>">
    <img src="https://images.unsplash.com/photo-1520975916090-3105956dac38?q=80&w=1920&auto=format&fit=crop" alt="" loading="eager" decoding="async" />
  </div>
  <div class="wrapper hero-inner">
    <h1><?php bloginfo('name'); ?></h1>
    <p><?php bloginfo('description'); ?></p>
    <p style="margin-top:.75rem;">
      <a class="btn" href="<?php echo esc_url( home_url('/kontakt') ); ?>"><?php _e('Kontakt aufnehmen','kneipzentrum'); ?></a>
      <a class="btn" href="<?php echo esc_url( home_url('/5-elemente') ); ?>" style="background:transparent;color:#0B1F3B;border-color:#0B1F3B"><?php _e('Die 5 Elemente','kneipzentrum'); ?></a>
    </p>
  </div>
</section>
<?php get_footer(); ?>
