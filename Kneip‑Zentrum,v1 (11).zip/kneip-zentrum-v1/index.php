<?php
/**
 * Index Template
 * Zweck: Fallback-Template mit einfachem Loop.
 */
get_header();
?>
<main class="wrapper" role="main" aria-label="<?php esc_attr_e('Inhalt','kneipzentrum'); ?>">
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <h1 class="page-title"><?php the_title(); ?></h1>
      <div class="entry">
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; else: ?>
    <p><?php esc_html_e('Noch keine Inhalte vorhanden.','kneipzentrum'); ?></p>
  <?php endif; ?>
</main>
<?php get_footer(); ?>
