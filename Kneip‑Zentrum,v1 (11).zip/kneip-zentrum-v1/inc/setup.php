<?php
/**
 * Admin-Setup-Seite (kollisionsfrei)
 * Zweck: Geführte Ersteinrichtung (Seiten, Menüs, Startseite), Tabs (Assistent/Manuell),
 * AJAX-Schritte, optional KI-Chat. Alle Funktionen/Actions mit Präfix kzs_.
 */

if ( ! defined('ABSPATH') ) { exit; }

/** Menüpunkt unter "Design" */
function kzs_register_setup_page(){
  add_theme_page(
    __('Kneipp‑Zentrum Setup','kneipzentrum'),
    __('Kneipp‑Zentrum Setup','kneipzentrum'),
    'manage_options',
    'kzs-setup',
    'kzs_render_setup_page'
  );
}
add_action('admin_menu','kzs_register_setup_page');

/** Hilfsfunktion: Seite sicherstellen */
function kzs_ensure_page($title, $content = '', $template = '', $parent = 0, $menu_order = 0){
  $existing = get_page_by_title( $title );
  if ( $existing ) {
    $id = (int)$existing->ID;
    if ($template) {
      update_post_meta($id, '_wp_page_template', sanitize_text_field($template) );
    }
  } else {
    $id = wp_insert_post([
      'post_title'   => $title,
      'post_status'  => 'publish',
      'post_type'    => 'page',
      'post_parent'  => (int)$parent,
      'menu_order'   => (int)$menu_order,
      'post_content' => $content,
    ]);
    if ($template && $id && !is_wp_error($id)) {
      update_post_meta($id, '_wp_page_template', sanitize_text_field($template) );
    }
  }
  return (int)$id;
}

/** Status ermitteln */
function kzs_get_status(){
  $status = [
    'menus' => [
      'primary' => has_nav_menu('primary'),
      'footer'  => has_nav_menu('footer'),
    ],
    'pages' => [
      'start'      => (bool) get_page_by_title('Start'),
      'ueber'      => (bool) get_page_by_title('Über uns'),
      'kontakt'    => (bool) get_page_by_title('Kontakt'),
      'impressum'  => (bool) get_page_by_title('Impressum'),
      'datenschutz'=> (bool) get_page_by_title('Datenschutz'),
    ],
    'elements' => [
      'hub'        => (bool) get_page_by_title('5 Elemente'),
      'wasser'     => (bool) get_page_by_title('Wasser'),
      'bewegung'   => (bool) get_page_by_title('Bewegung'),
      'ernaehrung' => (bool) get_page_by_title('Ernährung'),
      'heilpflanzen' => (bool) get_page_by_title('Heilpflanzen'),
      'balance'    => (bool) get_page_by_title('Balance'),
    ],
    'front' => [
      'is_static'  => ( 'page' === get_option('show_on_front') ),
      'page_on_front' => (int) get_option('page_on_front'),
    ],
  ];
  return $status;
}

/** Render: Setup-Seite (mit Tabs) */
function kzs_render_setup_page(){
  if ( ! current_user_can('manage_options') ) {
    wp_die( esc_html__('Keine Berechtigung.','kneipzentrum') );
  }

  $status = kzs_get_status();
  $ajax_nonce = wp_create_nonce('kzs_setup_ajax');
  $ai_nonce = wp_create_nonce('kzs_ai_chat');
  $ai = get_option('kz_ai_settings', ['provider'=>'openai','model'=>'gpt-4o-mini','api_key'=>'']);

  ?>
  <div class="wrap kz-setup">
    <h1><?php echo esc_html__('Kneipp‑Zentrum Setup','kneipzentrum'); ?></h1>

    <h2 class="nav-tab-wrapper">
      <a href="#kzs-tab-assistant" class="nav-tab nav-tab-active" onclick="kzsTabs(event)"><?php esc_html_e('Assistent','kneipzentrum'); ?></a>
      <a href="#kzs-tab-manual" class="nav-tab" onclick="kzsTabs(event)"><?php esc_html_e('Manuell','kneipzentrum'); ?></a>
      <a href="#kzs-tab-ai" class="nav-tab" onclick="kzsTabs(event)"><?php esc_html_e('Chat‑Einstellungen','kneipzentrum'); ?></a>
    </h2>

    <div class="kz-status">
      <span class="kz-chip <?php echo $status['menus']['primary'] && $status['menus']['footer'] ? 'kz-chip--ok':''; ?>">✔ <?php esc_html_e('Menüs','kneipzentrum'); ?></span>
      <span class="kz-chip <?php echo ( (int)$status['pages']['start'] + (int)$status['pages']['ueber'] + (int)$status['pages']['kontakt'] + (int)$status['pages']['impressum'] + (int)$status['pages']['datenschutz'] )===5 ? 'kz-chip--ok':''; ?>">✔ <?php esc_html_e('Standardseiten','kneipzentrum'); ?></span>
      <span class="kz-chip <?php echo ( (int)$status['elements']['hub'] + (int)$status['elements']['wasser'] + (int)$status['elements']['bewegung'] + (int)$status['elements']['ernaehrung'] + (int)$status['elements']['heilpflanzen'] + (int)$status['elements']['balance'] )===6 ? 'kz-chip--ok':''; ?>">✔ <?php esc_html_e('5 Elemente','kneipzentrum'); ?></span>
      <span class="kz-chip <?php echo $status['front']['is_static'] ? 'kz-chip--ok':''; ?>">✔ <?php esc_html_e('Startseite gesetzt','kneipzentrum'); ?></span>
    </div>

    <!-- Assistent -->
    <div id="kzs-tab-assistant" class="kz-tab" style="display:block">
      <div class="kz-chat" data-nonce="<?php echo esc_attr($ai_nonce); ?>" data-ajax="<?php echo esc_url( admin_url('admin-ajax.php') ); ?>" data-setup-nonce="<?php echo esc_attr($ajax_nonce); ?>">
        <div class="kz-chat-head"><?php esc_html_e('Setup‑Assistent','kneipzentrum'); ?> <small style="color:#64748b">– <?php esc_html_e('lokal, optional KI‑gestützt','kneipzentrum'); ?></small></div>
        <div class="kz-chat-body" id="kzsChatBody" aria-live="polite">
          <div class="kz-msg kz-msg--ai"><?php esc_html_e('Hallo! Ich helfe dir bei der Einrichtung. Was möchtest du tun?','kneipzentrum'); ?>
            <div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap">
              <button type="button" class="button button-secondary" onclick="kzsRunStep('create_menus')"><?php esc_html_e('Menüs anlegen','kneipzentrum'); ?></button>
              <button type="button" class="button button-secondary" onclick="kzsRunStep('create_pages')"><?php esc_html_e('Standardseiten','kneipzentrum'); ?></button>
              <button type="button" class="button button-secondary" onclick="kzsRunStep('create_elements')"><?php esc_html_e('5 Elemente','kneipzentrum'); ?></button>
              <button type="button" class="button button-secondary" onclick="kzsRunStep('set_front')"><?php esc_html_e('Startseite setzen','kneipzentrum'); ?></button>
              <button type="button" class="button button-secondary" onclick="kzsRunStep('flush_rewrite')"><?php esc_html_e('Permalinks aktualisieren','kneipzentrum'); ?></button>
            </div>
          </div>
        </div>
        <div class="kz-chat-foot">
          <input type="text" id="kzsChatInput" placeholder="<?php esc_attr_e('Frage oder Befehl eingeben …','kneipzentrum'); ?>" style="flex:1" />
          <button type="button" class="button button-primary" onclick="kzsSendChat()"><?php esc_html_e('Senden','kneipzentrum'); ?></button>
        </div>
      </div>
    </div>

    <!-- Manuell -->
    <div id="kzs-tab-manual" class="kz-tab" style="display:none">
      <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <?php wp_nonce_field('kzs_setup_nonce','kzs_setup_nonce'); ?>
        <input type="hidden" name="action" value="kzs_do_setup" />

        <table class="form-table" role="presentation">
          <tbody>
            <tr>
              <th scope="row"><?php esc_html_e('Menüs','kneipzentrum'); ?></th>
              <td>
                <label><input type="checkbox" name="create_menus" value="1" checked /> <?php esc_html_e('Haupt- und Footer-Menü anlegen und zuweisen','kneipzentrum'); ?></label>
              </td>
            </tr>
            <tr>
              <th scope="row"><?php esc_html_e('Standardseiten','kneipzentrum'); ?></th>
              <td>
                <label><input type="checkbox" name="create_pages" value="1" checked /> <?php esc_html_e('Start, Über uns, Kontakt, Impressum, Datenschutz erstellen (mit Beispielinhalten)','kneipzentrum'); ?></label><br />
                <label><input type="checkbox" name="create_elements" value="1" checked /> <?php esc_html_e('„5 Elemente“-Hub + Unterseiten (Wasser, Bewegung, Ernährung, Heilpflanzen, Balance) erstellen','kneipzentrum'); ?></label>
              </td>
            </tr>
            <tr>
              <th scope="row"><?php esc_html_e('Startseite','kneipzentrum'); ?></th>
              <td>
                <label><input type="checkbox" name="set_front" value="1" /> <?php esc_html_e('„Start“ als statische Startseite setzen','kneipzentrum'); ?></label>
              </td>
            </tr>
            <tr>
              <th scope="row"><?php esc_html_e('Permalinks','kneipzentrum'); ?></th>
              <td>
                <label><input type="checkbox" name="flush_rewrite" value="1" /> <?php esc_html_e('Rewrite-Regeln leeren (empfohlen nach Aktivierung)','kneipzentrum'); ?></label>
              </td>
            </tr>
          </tbody>
        </table>

        <?php submit_button( __('Einrichtung jetzt durchführen','kneipzentrum') ); ?>
      </form>
    </div>

    <!-- Chat-Einstellungen -->
    <div id="kzs-tab-ai" class="kz-tab" style="display:none">
      <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <?php wp_nonce_field('kz_ai_save','kz_ai_nonce'); ?>
        <input type="hidden" name="action" value="kz_ai_save" />
        <p><?php esc_html_e('Optional: API‑Key hinterlegen, um den Chat‑Assistenten KI‑gestützt zu nutzen. Ohne Key arbeitet der Assistent lokal (regelbasiert).','kneipzentrum'); ?></p>
        <div class="kz-row">
          <label><?php esc_html_e('Provider','kneipzentrum'); ?>:
            <select name="provider">
              <option value="openai" <?php selected(($ai['provider']??'openai'),'openai'); ?>>OpenAI</option>
            </select>
          </label>
          <label><?php esc_html_e('Modell','kneipzentrum'); ?>:
            <input type="text" name="model" value="<?php echo esc_attr($ai['model'] ?? 'gpt-4o-mini'); ?>" placeholder="z. B. gpt-5, gpt-4o-mini" />
          </label>
          <label style="flex:1"><?php esc_html_e('API‑Key','kneipzentrum'); ?>:
            <input type="password" name="api_key" value="<?php echo esc_attr($ai['api_key'] ?? ''); ?>" placeholder="sk-..." style="width:100%" />
          </label>
        </div>
        <?php submit_button( __('Einstellungen speichern','kneipzentrum') ); ?>
      </form>
      <p style="color:#64748b"><?php esc_html_e('Hinweis: Es werden nur Inhalte gesendet, die Sie in der Chat-Eingabe übermitteln. Bitte keine sensiblen personenbezogenen Daten eingeben.','kneipzentrum'); ?></p>
    </div>
  </div>

  <script>
    // Tabs
    function kzsTabs(e){
      e.preventDefault();
      document.querySelectorAll('.nav-tab').forEach(el=>el.classList.remove('nav-tab-active'));
      e.target.classList.add('nav-tab-active');
      document.querySelectorAll('.kz-tab').forEach(el=>el.style.display='none');
      const id = e.target.getAttribute('href');
      const pane = document.querySelector(id);
      if (pane) pane.style.display='block';
    }

    // Chat: Regelbasiert lokal, optional KI via AJAX (wenn API-Key vorhanden)
    async function kzsSendChat(){
      const input = document.getElementById('kzsChatInput');
      const body = document.getElementById('kzsChatBody');
      const text = (input.value || '').trim();
      if (!text) return;
      const me = document.createElement('div');
      me.className = 'kz-msg kz-msg--me';
      me.textContent = text;
      body.appendChild(me);
      input.value = '';

      const wrap = document.querySelector('.kz-chat');
      const ajax = wrap.getAttribute('data-ajax');
      const nonce = wrap.getAttribute('data-nonce');
      try{
        const res = await fetch(ajax, {
          method:'POST',
          headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ action:'kzs_ai_chat', _ajax_nonce: nonce, message: text })
        });
        const data = await res.json();
        const ai = document.createElement('div');
        ai.className = 'kz-msg kz-msg--ai';
        ai.innerHTML = data && data.message ? data.message : '<?php echo esc_js(__('Ich habe dazu leider keine Information.','kneipzentrum')); ?>';
        body.appendChild(ai);
        body.scrollTop = body.scrollHeight;
      }catch(err){
        const lower = text.toLowerCase();
        let reply = '';
        if (lower.includes('menü') || lower.includes('menu')) reply = '<?php echo esc_js(__('Ich kann die Menüs jetzt anlegen. Klicke auf „Menüs anlegen“.','kneipzentrum')); ?>';
        else if (lower.includes('seite') || lower.includes('seiten')) reply = '<?php echo esc_js(__('Ich kann Standardseiten erstellen. Klicke auf „Standardseiten“.','kneipzentrum')); ?>';
        else if (lower.includes('element')) reply = '<?php echo esc_js(__('Ich lege die 5‑Elemente-Seiten an. Klicke auf „5 Elemente“.','kneipzentrum')); ?>';
        else if (lower.includes('start')) reply = '<?php echo esc_js(__('Ich setze „Start“ als Startseite. Klicke auf „Startseite setzen“.','kneipzentrum')); ?>';
        else if (lower.includes('permalink') || lower.includes('rewrite')) reply = '<?php echo esc_js(__('Ich kann die Permalinks aktualisieren. Klicke auf „Permalinks aktualisieren“.','kneipzentrum')); ?>';
        else reply = '<?php echo esc_js(__('Ich schlage vor, mit Standardseiten zu beginnen.','kneipzentrum')); ?>';
        const ai = document.createElement('div');
        ai.className = 'kz-msg kz-msg--ai';
        ai.textContent = reply;
        body.appendChild(ai);
        body.scrollTop = body.scrollHeight;
      }
    }

    // Schnelle Buttons: AJAX-Schritte
    async function kzsRunStep(step){
      const wrap = document.querySelector('.kz-chat');
      const ajax = wrap.getAttribute('data-ajax');
      const nonce = wrap.getAttribute('data-setup-nonce');
      const body = document.getElementById('kzsChatBody');

      const note = document.createElement('div');
      note.className = 'kz-msg kz-msg--me';
      note.textContent = '→ ' + step;
      body.appendChild(note);

      const res = await fetch(ajax, {
        method:'POST',
        headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ action:'kzs_do_step', _ajax_nonce: nonce, step })
      });
      const data = await res.json();
      const ai = document.createElement('div');
      ai.className = 'kz-msg kz-msg--ai';
      ai.innerHTML = data && data.message ? data.message : '<?php echo esc_js(__('Fertig.','kneipzentrum')); ?>';
      body.appendChild(ai);
      body.scrollTop = body.scrollHeight;
    }
  </script>
  <?php
}

/** admin-post: Manuelle Ausführung */
add_action('admin_post_kzs_do_setup','kzs_handle_setup_action');

/** Handler: führt die ausgewählten Schritte aus (manuell). */
function kzs_handle_setup_action(){
  if ( ! current_user_can('manage_options') ) {
    wp_die( esc_html__('Keine Berechtigung.','kneipzentrum') );
  }
  if ( ! isset($_POST['kzs_setup_nonce']) || ! wp_verify_nonce($_POST['kzs_setup_nonce'], 'kzs_setup_nonce') ) {
    wp_die( esc_html__('Sicherheitsprüfung fehlgeschlagen.','kneipzentrum') );
  }

  if ( isset($_POST['create_menus']) ) {
    kzs_step_create_menus();
  }
  if ( isset($_POST['create_pages']) ) {
    kzs_step_create_pages();
  }
  if ( isset($_POST['create_elements']) ) {
    kzs_step_create_elements();
  }
  if ( isset($_POST['set_front']) ) {
    kzs_step_set_front();
  }
  if ( isset($_POST['flush_rewrite']) ) {
    flush_rewrite_rules();
  }

  wp_safe_redirect( add_query_arg('kz_setup','done', admin_url('themes.php?page=kzs-setup') ) );
  exit;
}

/** AJAX: Einzelschritte */
add_action('wp_ajax_kzs_do_step','kzs_ajax_do_step');

/** AJAX-Handler für einzelne Setup-Schritte. */
function kzs_ajax_do_step(){
  if ( ! current_user_can('manage_options') ) {
    wp_send_json_error(['message'=>__('Keine Berechtigung.','kneipzentrum')], 403);
  }
  check_ajax_referer('kzs_setup_ajax');

  $step = sanitize_text_field($_POST['step'] ?? '');
  switch ($step){
    case 'create_menus':
      kzs_step_create_menus();
      wp_send_json_success(['message'=>__('Menüs angelegt/zugewiesen.','kneipzentrum')]);
    case 'create_pages':
      kzs_step_create_pages();
      wp_send_json_success(['message'=>__('Standardseiten erstellt/aktualisiert.','kneipzentrum')]);
    case 'create_elements':
      kzs_step_create_elements();
      wp_send_json_success(['message'=>__('5‑Elemente‑Seiten erstellt/aktualisiert.','kneipzentrum')]);
    case 'set_front':
      kzs_step_set_front();
      wp_send_json_success(['message'=>__('„Start“ als Startseite gesetzt.','kneipzentrum')]);
    case 'flush_rewrite':
      flush_rewrite_rules();
      wp_send_json_success(['message'=>__('Permalinks aktualisiert.','kneipzentrum')]);
    default:
      wp_send_json_error(['message'=>__('Unbekannter Schritt.','kneipzentrum')], 400);
  }
}

/** Schritt: Menüs anlegen + zuweisen. */
function kzs_step_create_menus(){
  $safeCount = function($maybe){ return is_array($maybe) ? count($maybe) : 0; };

  // Hauptmenü
  $primary_id = wp_get_nav_menu_object('Hauptmenü') ? wp_get_nav_menu_object('Hauptmenü')->term_id : 0;
  if ( ! $primary_id ) {
    $primary_id = wp_create_nav_menu('Hauptmenü');
  }
  // Footer
  $footer_id = wp_get_nav_menu_object('Footer-Menü') ? wp_get_nav_menu_object('Footer-Menü')->term_id : 0;
  if ( ! $footer_id ) {
    $footer_id = wp_create_nav_menu('Footer-Menü');
  }

  // Hauptmenü-Einträge
  $items_primary = wp_get_nav_menu_items($primary_id);
  if ( $items_primary === false || $safeCount($items_primary) === 0 ){
    wp_update_nav_menu_item($primary_id, 0, [
      'menu-item-title'  => __('Start','kneipzentrum'),
      'menu-item-url'    => home_url('/'),
      'menu-item-status' => 'publish',
    ]);
    $ueber = get_page_by_title('Über uns');
    if ($ueber){
      wp_update_nav_menu_item($primary_id, 0, [
        'menu-item-title'  => __('Über uns','kneipzentrum'),
        'menu-item-object' => 'page',
        'menu-item-object-id' => (int)$ueber->ID,
        'menu-item-type'   => 'post_type',
        'menu-item-status' => 'publish',
      ]);
    }
    $kontakt = get_page_by_title('Kontakt');
    if ($kontakt){
      wp_update_nav_menu_item($primary_id, 0, [
        'menu-item-title'  => __('Kontakt','kneipzentrum'),
        'menu-item-object' => 'page',
        'menu-item-object-id' => (int)$kontakt->ID,
        'menu-item-type'   => 'post_type',
        'menu-item-status' => 'publish',
      ]);
    }
  }

  // Footer-Menü-Einträge
  $items_footer = wp_get_nav_menu_items($footer_id);
  if ( $items_footer === false || $safeCount($items_footer) === 0 ){
    foreach (['Impressum','Datenschutz','Kontakt'] as $t){
      $p = get_page_by_title($t);
      if ($p){
        wp_update_nav_menu_item($footer_id, 0, [
          'menu-item-title'  => $t,
          'menu-item-object' => 'page',
          'menu-item-object-id' => (int)$p->ID,
          'menu-item-type'   => 'post_type',
          'menu-item-status' => 'publish',
        ]);
      }
    }
  }

  // Zuweisen
  $locations = get_theme_mod('nav_menu_locations');
  if ( ! is_array($locations) ) $locations = [];
  $locations['primary'] = (int)$primary_id;
  $locations['footer']  = (int)$footer_id;
  set_theme_mod('nav_menu_locations', $locations);
}

/** Schritt: Standardseiten erstellen. */
function kzs_step_create_pages(){
  $front_id = kzs_ensure_page('Start', __('Willkommen! Diese Startseite kann frei angepasst werden. Die visuelle Startseite wird vom Template „front-page.php“ gerendert.','kneipzentrum'), '');
  kzs_ensure_page('Über uns', '', 'page-ueber-uns.php');
  kzs_ensure_page('Kontakt', '', 'page-kontakt.php');
  kzs_ensure_page('Impressum', '', 'page-impressum.php');
  kzs_ensure_page('Datenschutz', '', 'page-datenschutz.php');
}

/** Schritt: 5‑Elemente-Seiten erstellen. */
function kzs_step_create_elements(){
  $hub_id = kzs_ensure_page('5 Elemente', '', 'page-elemente.php');
  kzs_ensure_page('Wasser', '', 'page-element-wasser.php', $hub_id, 1);
  kzs_ensure_page('Bewegung', '', 'page-element-bewegung.php', $hub_id, 2);
  kzs_ensure_page('Ernährung', '', 'page-element-ernaehrung.php', $hub_id, 3);
  kzs_ensure_page('Heilpflanzen', '', 'page-element-heilpflanzen.php', $hub_id, 4);
  kzs_ensure_page('Balance', '', 'page-element-balance.php', $hub_id, 5);
}

/** Schritt: Startseite setzen. */
function kzs_step_set_front(){
  $start = get_page_by_title('Start');
  if ($start){
    update_option('show_on_front','page');
    update_option('page_on_front',(int)$start->ID);
  }
}

/** AJAX: Chat (optional KI) */
add_action('wp_ajax_kzs_ai_chat','kzs_ajax_ai_chat');

/** AJAX-Handler: Chat-Antwort. */
function kzs_ajax_ai_chat(){
  if ( ! current_user_can('manage_options') ) {
    wp_send_json_error(['message'=>__('Keine Berechtigung.','kneipzentrum')], 403);
  }
  check_ajax_referer('kzs_ai_chat');

  $message = sanitize_text_field($_POST['message'] ?? '');
  if ($message === ''){
    wp_send_json_error(['message'=>__('Leere Anfrage.','kneipzentrum')], 400);
  }

  $ai = get_option('kz_ai_settings', ['provider'=>'openai','model'=>'gpt-4o-mini','api_key'=>'']);
  $key = $ai['api_key'] ?? '';
  $model = $ai['model'] ?? 'gpt-4o-mini';

  if ( ! empty($key) ){
    $resp = wp_remote_post('https://api.openai.com/v1/chat/completions', [
      'timeout' => 20,
      'headers' => [
        'Content-Type'=>'application/json',
        'Authorization'=>'Bearer ' . $key,
      ],
      'body' => wp_json_encode([
        'model' => $model,
        'messages' => [
          [ 'role'=>'system', 'content'=>'Du bist ein Setup-Assistent für ein WordPress-Vereins-Theme (Kneipp Zentrum). Antworte kurz, klar, in deutscher Sprache. Biete ggf. Buttons als Empfehlung an (z. B. Menüs anlegen, Standardseiten).' ],
          [ 'role'=>'user', 'content'=> $message ],
        ],
        'temperature' => 0.2,
      ]),
    ]);

    if ( is_wp_error($resp) ){
      wp_send_json_error(['message'=>__('KI-Anfrage fehlgeschlagen, lokaler Modus aktiv.','kneipzentrum')], 500);
    }
    $code = wp_remote_retrieve_response_code($resp);
    $body = json_decode( wp_remote_retrieve_body($resp), true);
    if ($code >= 200 && $code < 300 && isset($body['choices'][0]['message']['content'])){
      $answer = wp_kses_post( nl2br( esc_html( $body['choices'][0]['message']['content'] ) ) );
      $answer .= '<div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap">
        <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_menus\')">Menüs anlegen</button>
        <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_pages\')">Standardseiten</button>
        <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_elements\')">5 Elemente</button>
        <button type="button" class="button button-secondary" onclick="kzsRunStep(\'set_front\')">Startseite setzen</button>
        <button type="button" class="button button-secondary" onclick="kzsRunStep(\'flush_rewrite\')">Permalinks aktualisieren</button>
      </div>';
      wp_send_json_success(['message'=>$answer]);
    } else {
      wp_send_json_error(['message'=>__('KI-Antwort ungültig, lokaler Modus aktiv.','kneipzentrum')], 500);
    }
  }

  // Lokaler Fallback
  $lower = function_exists('mb_strtolower') ? mb_strtolower($message) : strtolower($message);
  if ( strpos($lower,'menü')!==false || strpos($lower,'menu')!==false ){
    $answer = __('Ich kann die Menüs jetzt anlegen. Nutze die Aktion unten.','kneipzentrum');
  } elseif ( strpos($lower,'seite')!==false || strpos($lower,'seiten')!==false ){
    $answer = __('Ich kann Standardseiten erstellen. Nutze die Aktion unten.','kneipzentrum');
  } elseif ( strpos($lower,'element')!==false ){
    $answer = __('Ich erstelle die 5‑Elemente-Seiten. Nutze die Aktion unten.','kneipzentrum');
  } elseif ( strpos($lower,'start')!==false ){
    $answer = __('Ich setze „Start“ als Startseite. Nutze die Aktion unten.','kneipzentrum');
  } elseif ( strpos($lower,'permalink')!==false || strpos($lower,'rewrite')!==false ){
    $answer = __('Ich kann die Permalinks aktualisieren. Nutze die Aktion unten.','kneipzentrum');
  } else {
    $answer = __('Ich schlage vor, mit Standardseiten zu beginnen.','kneipzentrum');
  }
  $answer = wp_kses_post( nl2br( esc_html( $answer ) ) );
  $answer .= '<div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap">
    <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_menus\')">Menüs anlegen</button>
    <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_pages\')">Standardseiten</button>
    <button type="button" class="button button-secondary" onclick="kzsRunStep(\'create_elements\')">5 Elemente</button>
    <button type="button" class="button button-secondary" onclick="kzsRunStep(\'set_front\')">Startseite setzen</button>
    <button type="button" class="button button-secondary" onclick="kzsRunStep(\'flush_rewrite\')">Permalinks aktualisieren</button>
  </div>';
  wp_send_json_success(['message'=>$answer]);
}
