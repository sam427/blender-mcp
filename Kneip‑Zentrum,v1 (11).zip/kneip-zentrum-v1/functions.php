<?php
/**
 * functions.php
 * Zweck: Theme-Setup (Title-Tag, Thumbnails), Menüs, Assets,
 * Kontaktformular-Handler (admin-post) und Einrichtungsassistent (inc/setup.php).
 */

if ( ! defined('ABSPATH') ) { exit; }

/**
 * Theme Setup
 * Registriert Supports und Menüs.
 */
function kz_setup(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', ['search-form','comment-list','comment-form','gallery','caption','style','script']);
  register_nav_menus([
    'primary' => __('Hauptmenü','kneipzentrum'),
    'footer'  => __('Footer-Menü','kneipzentrum'),
  ]);
}
add_action('after_setup_theme','kz_setup');

/**
 * Assets
 * Enqueue CSS/JS aus /assets.
 */
function kz_assets(){
  $ver = wp_get_theme()->get('Version');
  wp_enqueue_style('kz-main', get_template_directory_uri().'/assets/css/main.css', [], $ver, 'all');
  wp_enqueue_script('kz-main', get_template_directory_uri().'/assets/js/main.js', [], $ver, true);
}
add_action('wp_enqueue_scripts','kz_assets');

/**
 * Kontaktformular: admin-post Handler
 * Validiert Eingaben und sendet E-Mail an Admin.
 */
function kz_contact_routes(){
  add_action('admin_post_nopriv_kz_contact', 'kz_handle_contact');
  add_action('admin_post_kz_contact', 'kz_handle_contact');
}
add_action('init','kz_contact_routes');

/** Handle Kontaktformular-Einsendung. */
function kz_handle_contact(){
  if ( ! isset($_POST['_wpnonce']) || ! wp_verify_nonce($_POST['_wpnonce'],'kz_contact') ) {
    wp_die(__('Ungültige Anfrage.','kneipzentrum'));
  }
  $name = sanitize_text_field($_POST['name'] ?? '');
  $email = sanitize_email($_POST['email'] ?? '');
  $msg = sanitize_textarea_field($_POST['message'] ?? '');
  if (!$name || !$email || !$msg){
    wp_safe_redirect( add_query_arg('contact','missing', wp_get_referer() ) );
    exit;
  }
  $subject = sprintf(__('Kontaktanfrage von %s','kneipzentrum'), $name);
  $body = "Name: {$name}\nE-Mail: {$email}\n\nNachricht:\n{$msg}";
  wp_mail( get_option('admin_email'), $subject, $body, ['Reply-To: '.$email] );
  wp_safe_redirect( add_query_arg('contact','sent', wp_get_referer() ) );
  exit;
}

/** Einrichtungsassistent laden (Admin). */
require_once get_template_directory() . '/inc/setup.php';
