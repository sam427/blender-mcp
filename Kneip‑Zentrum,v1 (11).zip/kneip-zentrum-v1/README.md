# Kneip‑Zentrum,v1

Ein leichtes, responsives WordPress-Theme für Vereine nach Sebastian Kneipp.

## Setup-Assistent
- Assistent (Chat): lokal (regelbasiert) oder optional KI‑gestützt (OpenAI API‑Key)
- Einzelschritte via AJAX, sichere Nonces, kollisionsfreie Funktionen (kzs_*)

