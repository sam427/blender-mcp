<?php
/**
 * Header Template
 * Zweck: Grundstruktur, Meta, wp_head, Navigation, CI-Logo inline (Schloss + Welle).
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e('Zum Inhalt springen','kneipzentrum'); ?></a>
<header class="header" role="banner">
  <div class="wrapper header-inner">
    <a class="brand-figure" href="<?php echo esc_url( home_url('/') ); ?>" aria-label="<?php esc_attr_e('Startseite','kneipzentrum'); ?>">
      <?php echo wp_kses_post('
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 80" role="img" aria-label="Kneipp Zentrum Petershagen">
  <defs>
    <linearGradient id="waveGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0ea5e9"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="360" height="80" fill="transparent"/>
  <!-- Schloss-Skizze, dezent -->
  <g opacity="0.14" stroke="#60a5fa" fill="none" stroke-width="1.25" stroke-linejoin="round" stroke-linecap="round" transform="translate(200,12)">
    <path d="M0 54 H150"/>
    <path d="M14 54 V26 H30 V18 L22 10 L14 18 V26"/>
    <rect x="50" y="22" width="40" height="32" rx="2"/>
    <path d="M70 54 V42 a8 8 0 0 1 8 8 V54"/>
    <path d="M110 54 V24 H126 V16 L118 8 L110 16 V24"/>
    <path d="M52 22 h6 M62 22 h6 M72 22 h6 M82 22 h6"/>
  </g>
  <!-- Welle tiefer (Y=70), schlanker -->
  <path d="M0 70 C40 62, 80 62, 120 70 S200 78, 240 70 S320 62, 360 70" fill="none" stroke="url(#waveGrad)" stroke-width="4.25" stroke-linecap="round"/>
  <!-- Titel/Untertitel -->
  <text x="8" y="34" font-family="system-ui,Segoe UI,Arial" font-size="24" font-weight="800" fill="#0b3c8a">Kneipp Zentrum</text>
  <text x="8" y="56" font-family="system-ui,Segoe UI,Arial" font-size="16" font-weight="600" fill="#0369a1">Petershagen</text>
</svg>
'); ?>
      <h2 class="site-title" style="margin:0;">
        <?php bloginfo('name'); ?>
      </h2>
    </a>
    <?php if ( has_nav_menu('primary') ) : ?>
      <?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'primary-menu']); ?>
    <?php endif; ?>
  </div>
</header>
<div id="content">
